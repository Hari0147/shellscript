#!/bin/bash

echo 'This is my first shell script'
echo
echo "I have \$100 to buy a book but I will buy the buy the book with $NAME account"
