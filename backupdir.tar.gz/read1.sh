#!/bin/bash

read -p "Ente your username: " USR
read -sp "Enter your password: " PASS
echo
echo "Login successful. Welcome $USR user"
