 #!/bin/bash

 read -p "Enter your skills: " SKILLS
 echo

 echo "Your $SKILLS skills are very popular in IT industry"
