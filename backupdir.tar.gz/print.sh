echo "This is my shell script"
echo
echo "I need to practice a lot and I don't want to waste my time anymore"
echo "I have a lot task to complete"
echo "Please god be with me and also help me to complete these tasks as soon as possible"
