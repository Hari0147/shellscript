#!/bin/bash

VAR1=1234
echo "my telephone number is $VAR1"
echo "my real name is $NAME"
