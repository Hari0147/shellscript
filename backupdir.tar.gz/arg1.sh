#!/bin/bash

echo "First argument is "
echo $0
